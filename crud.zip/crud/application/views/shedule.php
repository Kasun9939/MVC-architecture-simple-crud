<html>
    <head>
        <title>Code Test</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8">

                    <h2>List of Re Eploanshedule</h2>
                    <table class="table">
                     
                        <tr>
                            <td>Cap Amount</td>
                            <td>Int Amount</td>
                            <td>Total Instalment</td>
                            <td>Due date</td>
                         

                        </tr>
                        <?php
                        foreach ($register_detail as $rg) {
                            ?>
                            <tr>
                                <td><?php echo $rg['cap_amount']; ?></td>
                                <td><?php echo $rg['int_amount']; ?></td>
                                <td><?php echo $rg['tot_instalment']; ?></td>
                                <td><?php echo $rg['deu_date']; ?></td>
                               
                            </tr>
                            <?php
                        }
                        ?>
                    </table>
                </div>
                <div class="col-md-2"></div>
            </div>
        </div>
    </body>
</html> 