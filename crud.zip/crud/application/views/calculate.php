<html>
    <head>
    <title>Code Test</title>  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">  

      <script type="text/javascript">
      
          function calculate(){
            var p = 0;
            var i = 0;
            var n = 0;
            var m = 0;
            var CI = 0;

            p = parseInt(document.getElementById("principal").value);
            i = parseInt(document.getElementById("annual_interest_rate").value);
            n = parseInt(document.getElementById("number_of_period").value);

            m=n/12;
            CI = (p*((i/365))*n);
            document.getElementById("res").innerHTML=CI;
          }
      </script>
     </head>

    <body class="body">
      <br>
    <div class="container">
      <div class="card text-black bg-light mb-9" style="max-width: 200rem;">
       
          <div class="container">
          <div class="row">
            <div class="col-md-12">
              <h1 id="title">Daily Interest Calculator</h1>
            </div>
          </div>
          <br>

          <div class="row">
            <div class="col-md-12">
        <form>
            <div class="form-group">
                  <label class="form-group">Capital Amount</label>
                  <input class="form-control" type="text" id="principal" placeholder="Amount">
             </div>
              <div class="form-group">
                  <label class="form-group">Interest rate</label>
                  <input class="form-control" type="text" id="annual_interest_rate"
                  placeholder="Rate in %">
              </div>
              <div class="form-group">
                  <label class="form-group">Number of moths</label>
                  <input class="form-control" type="text" id="number_of_period"
                  placeholder="Period">
              </div>
              <button class="btn btn-block btn-info" type="button" onclick="calculate()">Calculate</button>
          </form>
            </div>
          </div>
          <br>
          <h5 class="total">Result</h5>
          
          <div class="row">
            <div class="col-md-12">
              <h1 id="res">0</h1>
            </div>
          </div>
        </div>
      </div>
    </div>

    </body>
</html>