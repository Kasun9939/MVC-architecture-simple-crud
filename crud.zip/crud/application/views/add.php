<html>
    <head>
        <title>Code Test</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <form method="post" name="frmAdd" action="<?php echo base_url(); ?>index.php/Register/add">
                        <h3>Add User</h3>

                        <div class="form-group">
                            <label for="">Customer Code</label>
                            <input type="text" class="form-control" name="txtCuscode">
                        </div>

                        <div class="form-group">
                            <label for="">Loan Code</label>
                            <input type="text" class="form-control" name="txtLcode">
                        </div>

                        <div class="form-group">
                            <label for="">Loan Amount</label>
                            <input type="text" class="form-control" name="txtLamount">
                        </div>

                        <div class="form-group">
                            <label for="">Period</label>
                            <input type="text" class="form-control" name="txtPeriod">
                        </div>

                        <div class="form-group">
                            <label for="">Interest</label>
                            <input type="text" class="form-control" name="txtInterest">
                        </div>
                        <div class="form-group">
                            <label for="">Instalment</label>
                            <input type="text" class="form-control" name="txtInstalment">
                        </div>
                        <div class="form-group">
                            <label for="">Rental</label>
                            <input type="text" class="form-control" name="txtMrental">
                        </div>
                        <div class="form-group">
                            <label for="">Interest Amount</label>
                            <input type="text" class="form-control" name="txtDelayinterest">
                        </div>
                        <div class="form-group">
                            <label for="">Start Date</label>
                            <input type="text" class="form-control" name="txtSdate">
                        </div>
                        <div class="form-group">
                            <label for="">End Date</label>
                            <input type="text" class="form-control" name="txtEdate">
                        </div>
                        <div class="form-group">
                            <label for="">Loan Status</label>
                            <input type="text" class="form-control" name="txtLstatus">
                        </div>

                        <div class="form-group">
                            <input type="submit" value="Add user now" name="btnadd" class="btn btn-primary btn-lg">
                        </div>

                    </form>
                    <div class="col-md-3"></div>
                </div>
            </div>
        </div>
    </body>
</html> 