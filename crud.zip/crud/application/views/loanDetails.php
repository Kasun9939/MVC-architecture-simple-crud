<!DOCTYPE html>
<html>
<head>
<title>Code Test</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<h2>Loan Details</h2>

<div style="overflow-x:auto;">
  <table>
    <tr>
      <th>Loan Amount</th>
      <th>Interest rate</th>
      <th>Loan period</th>
      <th>Start date</th>
     
    </tr>
    <?php
                        foreach ($register_detail as $rg) {
                            ?>
                            <tr>
                                <td><?php echo $rg['loan_amount']; ?></td>
                                <td><?php echo $rg['delay_interest']; ?></td>
                                <td><?php echo $rg['period']; ?></td>
                                <td><?php echo $rg['start_date']; ?></td>
                               
                            </tr>
                            <?php
                        }
                        ?>
  </table>
</div>

</body>
</html>

