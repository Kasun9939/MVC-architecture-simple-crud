<html>
    <head>
        <title>Code Test</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8">

                    <h2>List of Re Eploan</h2>
                    <table class="table">
                        <tr>
                            <td colspan="5" align="right"><a href="<?php echo base_url(); ?>index.php/Register/add">Add</a></td>
                        </tr>
                        <tr>
                            <td>Customer Code</td>
                            <td>Loan code</td>
                            <td>Loan amount</td>
                            <td>Period</td>
                            <td>Interest</td>
                            <td>Instalment</td>
                            <td>Rental</td>
                            <td>Interest Amount</td>
                            <td>Start Date</td>
                            <td>End_date</td>
                            <td>Loan Status</td>

                        </tr>
                        <?php
                        foreach ($register_detail as $rg) {
                            ?>
                            <tr>
                                <td><?php echo $rg['cus_code']; ?></td>
                                <td><?php echo $rg['loan_code']; ?></td>
                                <td><?php echo $rg['loan_amount']; ?></td>
                                <td><?php echo $rg['period']; ?></td>
                                <td><?php echo $rg['interest']; ?></td>
                                <td><?php echo $rg['instalments']; ?></td>
                                <td><?php echo $rg['montly_rental']; ?></td>
                                <td><?php echo $rg['delay_interest']; ?></td>
                                <td><?php echo $rg['start_date']; ?></td>
                                <td><?php echo $rg['end_date']; ?></td>
                                <td><?php echo $rg['loan_status']; ?></td>
                                <td><a  href="<?php echo base_url(); ?>index.php/Register/edit/<?php echo $rg['cus_code']; ?>">Edit</a> <a  href="<?php echo base_url(); ?>index.php/Register/delete/<?php echo $rg['cus_code']; ?>">Delete</a></td>
                            </tr>
                            <?php
                        }
                        ?>
                    </table>
                </div>
                <div class="col-md-2"></div>
            </div>
        </div>
    </body>
</html> 