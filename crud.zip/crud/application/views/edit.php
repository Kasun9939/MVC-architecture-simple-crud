<html>
    <head>
        <title>Code Test</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">

                    <form method="post" name="frmEdit">

                        <div>
                            <h3>Update User</h3>
                        </div>

                        <div class="form-group">
                            <td>Customer Code</td>
                            <label for="">Customer Code</label>
                            <input type="text" name="txtCuscode" value="<?php echo $register_detail[0]['cus_code']; ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <td>Loan code</td>
                            <input type="text" name="txtLcode" value="<?php echo $register_detail[0]['loan_code']; ?>"  class="form-control"> 
                        </div>
                        <div class="form-group">
                            <label for="">Loan amount</label>
                            <textarea name="txtLamount"  class="form-control"><?php echo $register_detail[0]['loan_amount']; ?></textarea> 
                        </div>
                        <div class="form-group">
                            <label for="">Period</label>
                            <input type="text" name="txtPeriod" value="<?php echo $register_detail[0]['period']; ?>"  class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Interest</label>
                            <input type="text" name="txtInterest" value="<?php echo $register_detail[0]['interest']; ?>"  class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Instalment</label>
                            <input type="text" name="txtInstalment" value="<?php echo $register_detail[0]['instalments']; ?>"  class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Rental</label>
                            <input type="text" name="txtMrental" value="<?php echo $register_detail[0]['montly_rental']; ?>"  class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Interest Amount</label>
                            <input type="text" name="txtDelayinterest" value="<?php echo $register_detail[0]['delay_interest']; ?>"  class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Start Date</label>
                            <input type="text" name="txtSdate" value="<?php echo $register_detail[0]['start_date']; ?>"  class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">End Date</label>
                            <input type="text" name="txtEdate" value="<?php echo $register_detail[0]['end_date']; ?>"  class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="">Loan Status</label>
                            <input type="text" name="txtLstatus" value="<?php echo $register_detail[0]['loan_status']; ?>"  class="form-control">
                        </div>
                        <div class="form-group">
                            <input type="submit" value="Edit Now" name="btnEdit" class="btn btn-primary btn-lg">
                        </div>

                    </form>
                    <div class="col-md-3"></div>
                </div>
            </div>
        </div>
    </body>
</html> 