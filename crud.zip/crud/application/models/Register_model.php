<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Register_model extends CI_Model {

    public function __construct() {
        $this->load->database('default');
        $this->load->library('session');

        // Call the Model constructor
        parent::__construct();
    }

    public function get_all_register_detail() {
        $this->db->select('*');
        $this->db->from('re_eploan');
        $objQuery = $this->db->get();
        return $objQuery->result_array();


        $this->db->select('cus_code, loan_code, loan_amount, period, interest, instalments, mountly_rental, delay_interest, start_date, end_date, loan_status');
        $this->db->from('cm_customerms');
        $this->db->join('re_eploan', 'cm_customerms.cus_code=re_eploan_cus_code');
        $query = $this->db->get();
  
      if($query->num_rows() != 0)
      {
          return $query->result();
      }
      else
      {
          return false;
      }



    }

    public function get_id_wise_register_detail($id) {
        $this->db->select('*');
        $this->db->from('re_eploan');
        $this->db->where('cus_code', $id);
        $objQuery = $this->db->get();
        return $objQuery->result_array();
    }

    public function insert($arrData) {
        if ($this->db->insert('re_eploan', $arrData)) {
            return true;
        } else {
            return false;
        }
    }

    public function update($editData, $id) {
        $this->db->where('cus_code', $id);

        if ($this->db->update('re_eploan', $editData)) {
            return true;
        } else {
            return false;
        }
    }

    function delete($id) {

        if ($this->db->delete('re_eploan', array('cus_code' => $id))) {
            return true;
        } else {
            return false;
        }
    }


    public function get_all_shedule_detail() {
        $this->db->select('*');
        $this->db->from('re_eploanshedule');
        $objQuery = $this->db->get();
        return $objQuery->result_array();
    }

    public function get_all_loanDetails_detail() {
        $this->db->select('*');
        $this->db->from('re_eploan');
        $objQuery = $this->db->get();
        return $objQuery->result_array();
    }

}

?>
