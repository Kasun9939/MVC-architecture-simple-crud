<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
       $this->load->model('register_model');
       
    }

    public function index() {
        $arrData['register_detail'] = $this->register_model->get_all_register_detail();
        $this->load->view('list', $arrData);
    }

    public function add() {
        if ($this->input->post('btnadd')) {
            $arrData['cus_code'] = $this->input->post('txtCuscode');
            $arrData['loan_code'] = $this->input->post('txtLcode');
            $arrData['loan_amount'] = $this->input->post('txtLamount');
            $arrData['period'] = $this->input->post('txtPeriod');
            $arrData['interest'] = $this->input->post('txtInterest');
            $arrData['instalments'] = $this->input->post('txtInstalment');
            $arrData['mountly_rental'] = $this->input->post('txtMrental');
            $arrData['delay_interest'] = $this->input->post('txtDelayinterest');
            $arrData['start_date'] = $this->input->post('txtSdate');
            $arrData['end_date'] = $this->input->post('txtEdate');
            $arrData['loan_status'] = $this->input->post('txtLstatus');
         

            $insert = $this->register_model->insert($arrData);
            if ($insert) {
                redirect('register');
            }
        }
        $this->load->view('add');
    }

    public function edit($id) {
        $arrData['register_detail'] = $this->register_model->get_id_wise_register_detail($id);

        if ($this->input->post('btnEdit')) {
            $editData['cus_code'] = $this->input->post('txtCuscode');
            $editData['loan_code'] = $this->input->post('txtLcode');
            $editData['loan_amount'] = $this->input->post('txtLamount');
            $editData['period'] = $this->input->post('txtPeriod');
            $editData['interest'] = $this->input->post('txtInterest');
            $editData['instalments'] = $this->input->post('txtInstalment');
            $editData['montly_rental'] = $this->input->post('txtMrental');
            $editData['delay_interest'] = $this->input->post('txtDelayinterest');
            $editData['start_date'] = $this->input->post('txtSdate');
            $editData['end_date'] = $this->input->post('txtEdate');
            $editData['loan_status'] = $this->input->post('txtLstatus');
            


            $update = $this->register_model->update($editData, $id);
            if ($update) {
                redirect('register');
            }
        }
        $this->load->view('edit', $arrData);
    }

    public function delete($id) {
        $delete = $this->register_model->delete($id);
        if ($delete) {
            redirect('register');
        }
    }

    
    public function shedule() {
        $arrData['register_detail'] = $this->register_model->get_all_shedule_detail();
        $this->load->view('shedule', $arrData);
    }


    public function loanDetails() {
        $arrData['register_detail'] = $this->register_model->get_all_loanDetails_detail();
        $this->load->view('loanDetails', $arrData);
    }

	public function calculate()
	{
		$this->load->view('calculate'); 
	}

}